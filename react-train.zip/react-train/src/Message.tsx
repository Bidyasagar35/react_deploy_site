function Message(){
    const Name= 'heh';
    return <h1>Hello World {Name}</h1>
}
export default Message;